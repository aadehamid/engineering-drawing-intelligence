# Decision records

One file per owner decision, holding the evidence behind it. The
[decision register](../LIONG-REG-001-decisions.md) stays the summary of approval
state; a register row links here when its decision has a record.

## Index

| ID | Decision | Status | Date |
| --- | --- | --- | --- |
| [DEC-014](DEC-014-skipped-question-convention.md) | A skipped question in a decision round counts as agreement | Decided | 2026-10-11 |
| [DEC-015](DEC-015-first-generation-slice.md) | The first generation work builds the R0 backend, its answer key, and one invalid variant | Decided | 2026-10-11 |
| [DEC-016](DEC-016-hand-authored-r0.md) | R0 is hand-authored, and seeds apply only to procedurally generated worlds | Decided | 2026-10-11 |
| [DEC-017](DEC-017-r0-is-the-visible-fixture.md) | LIONG-011 calls MILESTONE-001's input the visible R0 development fixture | Decided | 2026-10-11 |
| [DEC-018](DEC-018-canonical-world-data-file.md) | A canonical world is a declarative data file checked against a JSON Schema | Decided | 2026-10-11 |
| [DEC-019](DEC-019-generator-writes-files.md) | The generator writes backend files, and a separate loader applies them | Decided | 2026-10-11 |
| [DEC-020](DEC-020-vendor-style-backends.md) | Two synthetic backends follow SmartPlant P&ID and AutoCAD Plant 3D storage closely, with original names | Decided | 2026-10-11 |
| [DEC-021](DEC-021-synthetic-world-terms.md) | The glossary defines canonical world, source representation, and world lineage | Decided | 2026-10-11 |
| [DEC-022](DEC-022-postgresql-on-neon.md) | PostgreSQL on Neon hosts the synthetic backend | Superseded | 2026-10-11 |
| [DEC-023](DEC-023-guardrails-first.md) | The way-of-working guardrails land as five pull requests before the synthetic-data work | Decided | 2026-10-11 |
| [DEC-024](DEC-024-decision-records.md) | Each decision has its own record, and the register stays the summary | Decided | 2026-10-11 |
| [DEC-025](DEC-025-python-and-uv.md) | The generator uses Python 3.12 with dependencies locked by uv | Decided | 2026-10-11 |
| [DEC-026](DEC-026-reachable-backend-close-to-vendors.md) | The backend database is reachable from any of the owner's machines and runs on the engine closest to both vendors | Decided | 2026-10-11 |
| [DEC-027](DEC-027-sql-server-on-azure.md) | Both backends run on SQL Server, hosted on an Azure SQL Database free-offer database | Decided | 2026-10-11 |
| [DEC-028](DEC-028-one-database-two-schemas.md) | Both vendor schemas live in one database | Decided | 2026-10-11 |
| [DEC-029](DEC-029-two-canonical-worlds.md) | There are two canonical worlds, each generated into one vendor's schema | Decided | 2026-10-11 |
| [DEC-030](DEC-030-plant-3d-backend-first.md) | MILESTONE-001 builds the Plant 3D-style backend first | Decided | 2026-10-11 |
| [DEC-031](DEC-031-stored-data-not-behaviour.md) | The backends copy each application's saved data, not its editing behaviour | Decided | 2026-10-11 |
| [DEC-032](DEC-032-minimal-data-dictionary.md) | Each backend carries a minimal data dictionary for the classes R0 uses | Decided | 2026-10-11 |
| [DEC-033](DEC-033-architecture-wording.md) | ARCHITECTURE.md describes two synthetic backends that follow vendor storage patterns | Decided | 2026-10-11 |
| [DEC-034](DEC-034-r0-smartplant-cross-check.md) | R0 is also generated in SmartPlant form, as a test fixture for the two mappings | Decided | 2026-10-11 |
| [DEC-035](DEC-035-r0-is-the-autodesk-world.md) | R0 is the Autodesk world, and a new world W-SP is the SmartPlant world | Decided | 2026-10-12 |
| [DEC-036](DEC-036-w-sp-new-plant.md) | W-SP is a new hand-authored plant about R0's size, built around what SmartPlant stores differently | Decided | 2026-10-12 |
| [DEC-037](DEC-037-revision-snapshots.md) | Each source revision is one complete backend snapshot that fills in the vendor's own revision fields | Decided | 2026-10-12 |
| [DEC-038](DEC-038-moc-outside-vendor-schemas.md) | MOC records stay a separate source representation, outside both vendor schemas | Decided | 2026-10-12 |
| [DEC-039](DEC-039-approval-in-vendor-fields.md) | Each backend stores the source approval in its vendor's own fields | Decided | 2026-10-12 |
| [DEC-040](DEC-040-plant-3d-patterns.md) | The Plant 3D-style schema borrows six patterns from the vendor research, renamed and cited | Decided | 2026-10-12 |
| [DEC-041](DEC-041-vendor-style-backend-term.md) | The glossary defines vendor-style backend | Decided | 2026-10-12 |
| [DEC-042](DEC-042-w-sp-scn-001-first.md) | W-SP starts with only the SCN-001 equivalent | Decided | 2026-10-12 |
| [DEC-043](DEC-043-no-foreign-keys.md) | The vendor-style relationship tables have no foreign-key constraints | Decided | 2026-10-12 |
| [DEC-044](DEC-044-stable-separate-keys.md) | Keys stay the same across a world's snapshots, and the backends never share keys | Decided | 2026-10-12 |
| [DEC-045](DEC-045-revision-time-sources.md) | Each revision time comes from the system that records it | Decided | 2026-10-12 |
| [DEC-046](DEC-046-next-pr-order.md) | The next pull requests land in a set order | Decided | 2026-10-12 |
| [DEC-047](DEC-047-loader-outbox-schema.md) | The outbox lives in a third, non-vendor schema in the same SQL Server database | Decided | 2026-10-12 |
| [DEC-048](DEC-048-night-delegation.md) | The agent decides open questions for the owner during the night run of 2026-10-13 | Decided | 2026-10-13 |
| [DEC-049](DEC-049-plant-3d-schema-choices.md) | The Plant 3D-style schema is one T-SQL file, tested on SQL Server in CI, with tags split as the product splits them | Decided | 2026-10-13 |
| [DEC-050](DEC-050-p3d-generator-choices.md) | The Plant 3D-style generator writes one JSON file per table per revision, with a separate answer key | Decided | 2026-10-13 |
| [DEC-051](DEC-051-p3d-loader-choices.md) | The loader replaces the backend's rows with a snapshot and raises one outbox event per revision | Decided | 2026-10-13 |
| [DEC-052](DEC-052-w-sp-contents.md) | W-SP is a two-sheet transfer line whose one pipeline is two runs, with three inline valves | Decided | 2026-10-13 |
| [DEC-053](DEC-053-main-history-stays.md) | Main's history stays as it is, with four commits authored by a test identity | Decided | 2026-10-13 |
| [DEC-054](DEC-054-delegation-takes-precedence.md) | DEC-048's delegation takes precedence over DEC-036's reservation, so W-SP's contents stand | Decided | 2026-10-13 |
| [DEC-055](DEC-055-slice-choices-close-gates-on-evidence.md) | This round chooses components for MILESTONE-001's slice only, and a gate closes when a PR lands its closure evidence | Decided | 2026-10-13 |
| [DEC-056](DEC-056-neo4j-for-the-slice.md) | The slice's graph store is Neo4j Community 2026.09.0, run from a pinned image locally and in CI | Decided | 2026-10-13 |
| [DEC-057](DEC-057-cypher-query-no-ui.md) | Step 5 is a parameterized Cypher query run through the official neo4j Python driver, with no UI in the slice | Decided | 2026-10-13 |
| [DEC-058](DEC-058-json-run-manifests.md) | The slice's manifests and publication receipt are JSON files in a run output folder, with no PostgreSQL | Decided | 2026-10-13 |
| [DEC-059](DEC-059-exact-answer-key-comparison.md) | Step 6 compares the published graph with the answer key and requires an exact match | Decided | 2026-10-13 |
| [DEC-060](DEC-060-plain-python-orchestration.md) | Each slice step is a plain Python command, chained by one script, with no orchestrator | Decided | 2026-10-13 |
| [DEC-061](DEC-061-dexpi-2-0-1.md) | The slice targets DEXPI 2.0.1, pinned at the specification's V2.0.1 tag | Decided | 2026-10-13 |
| [DEC-062](DEC-062-vendored-model-files.md) | Pinned copies of the DEXPI model files live in the repository, and validation never fetches over the network | Decided | 2026-10-13 |
| [DEC-063](DEC-063-own-dexpi-generator-and-parser.md) | LIONG writes its own DEXPI 2.0.1 generator and parser for the supported subset, on lxml | Decided | 2026-10-13 |
| [DEC-064](DEC-064-four-stage-dexpi-validation.md) | A DEXPI file is valid only when it passes four named validation stages and an exact round trip | Decided | 2026-10-13 |
| [DEC-065](DEC-065-claim-names-stages-that-ran.md) | A DEXPI validity claim names only the stages that ran, never conformance or certification | Superseded | 2026-10-13 |
| [DEC-066](DEC-066-reference-pid-parser-test.md) | The parser also reads DEXPI's own 2.0.1 reference P&ID and reports what it does not support | Decided | 2026-10-13 |
| [DEC-067](DEC-067-exact-pins.md) | Every new slice component is pinned exactly, at the latest release at least 14 days old | Decided | 2026-10-13 |
| [DEC-068](DEC-068-supported-subset-term.md) | The glossary defines supported subset | Decided | 2026-10-13 |
| [DEC-069](DEC-069-bpmn2dexpi-recorded-not-used.md) | bpmn2dexpi is recorded as a candidate validator and kept out of the slice | Decided | 2026-10-13 |
| [DEC-070](DEC-070-delivery-playbook.md) | A general delivery playbook for engineering-data-to-graph projects lives in this repository | Decided | 2026-10-13 |
| [DEC-071](DEC-071-playbook-grows-with-prs.md) | A pull request that settles an engineering practice updates the playbook in the same pull request | Decided | 2026-10-13 |
| [DEC-072](DEC-072-claim-names-every-stage-that-ran.md) | A DEXPI validity claim names every stage that ran, including the reference checks | Decided | 2026-10-13 |
| [DEC-073](DEC-073-second-night-delegation.md) | The agent decides open questions for the owner during the night run of 2026-10-14 | Decided | 2026-10-14 |

## Record format

What each status means, when a decision is Decided, and how one decision amends
another follow the way-of-working standard (`references/deciding.md`). This
section fixes only the shape that `uv run python scripts/liong_facts.py check` verifies.

- **File name** `DEC-NNN-short-slug.md`, first line `# DEC-NNN: ` followed by the decision, then a
  `Status:` line (`Proposed`, `Decided`, or `Superseded`) and a `Date: YYYY-MM-DD`
  line.
- **No raw HTML or HTML comments** outside code. The review archive holds these
  records, and its rule is the same.
- **Sections**, in order and none empty: `## Context`, `## Decision`,
  `## Alternatives considered`, `## Owner's words`, `## Evidence`.
- **Owner's words** in a `Decided` record: a line `The owner answered:` (or
  `said:` or `wrote:`) followed by the quote in a `>` block of plain text: letters,
  digits, spaces and ordinary punctuation. The whole section holds no HTML,
  entities, or code.
- **Decision quotes**: the text a reader sees in each quote under Decision appears
  word for word inside one quote under Owner's words or Evidence. The check reads
  the record with a CommonMark parser, so emphasis, link markup, line breaks and
  spacing may differ, but a link title, an image's alt text or code outside the quote
  never counts as quoted words.
- **Supersession**: the earlier record has `Superseded by DEC-NNN on YYYY-MM-DD`,
  and the later record has a line `Amends DEC-NNN`.
- **Index**: one row per record, with the link, decision, status and date matching
  the record. Any other row in the Index table fails the check.
